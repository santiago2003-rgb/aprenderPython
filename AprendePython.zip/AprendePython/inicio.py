'''num1 = 2
num2 = 10 
resultado = num1 + num2

def resultadoSuma(num1, num2):
    return resultado

resultado = resultadoSuma(num1, num2)
print(resultado)'''

#Funciones de una sola linea LAMBDA
'''saluda = lambda: print("hola")
saluda()'''

#SINTAXIS BASICA
'''a = 2 + 2
if a:
    print(a)
else:
    print("No da")'''

#NUMEROS
'''edad = 30
pi = 3.14
salario = 1500.50

#NOTACIONES CIENTIFICAS
numeroGrande = 1e6
numeroPequeño = 1e-6

#NUMEROS DE TIPO INT
edad: int = 30

#NUMEROS DE TIPO FLOAT
pi: float = 3.14
salario: float = 1500.50'''

#STRINGS
'''nombre = "Platzi"
apellido = "Academy"

print("Hola, " + nombre + " " + apellido + "!")
print(f"hola, {nombre} {apellido}!")

nombre = "Platzi"
print(len(nombre))
print(nombre.upper())
print(nombre.lower())
print(nombre.split("a"))'''

#DICCIONARIOS
'''
    Los diccionarios son estructuras de datos que nos permiten almacenar un conjunto de pares clave-valor. Estos pares son conocidos como elementos del diccionario.
    
    Para crear un diccionario, debemos utilizar las llaves {} y especificar los elementos del diccionario mediante la sintaxis clave: valor. Los valores de los elementos pueden ser de cualquier tipo de dato, incluyendo otros diccionarios.


persona = {
    "nombre": "Fulantia",
    "platziRank": 9567,
    "cursoFavorito": {
        "nombre": "Basico de Python",
        "clases": 30,
        "duracion": "2 horas"
    }
}
print(persona["nombre"])
print(persona["cursoFavorito"]["nombre"])
print(persona["cursoFavorito"]["clases"])
print(persona["cursoFavorito"]["duracion"])
print(persona["platziRank"])'''


#BOOLEANOS
'''cursoCompletado = True
lecturaCompletada = False

type("#PlatziChallenge")'''

