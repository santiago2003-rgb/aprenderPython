#LISTAS
toDo = ["Dirigirnos al hotel",
        "Ir almorzar",
        "Visitar un museo",
        "Volver al hotel"]
print(toDo)

numbers = [1,2,3,4, "Cinco"]
print(type(numbers))

mix = ["uno", 2, 3.14, True, [1, 2 ,3]]
print(mix)
print(len(mix))
print("Primer elemento", mix[0])
print("Primer elemento", mix[1])
print("Primer elemento", mix[2])

string = "Hola mundo"
print("Primer elemento", string[0])
print("Primer elemento", string[1])
print("Primer elemento", string[2])
print(mix[2:-2])
print(mix)
mix.append(False)
print(mix)
mix.append(["a","b"])
print(mix)
mix.insert(1,["a","b"]) #INSERT SIRVE PARA DARLE LA POSICION A LO NUEVO QUE VAMOS AÑADIR A LA LISTA 
print(mix)
print(mix.index(["a","b"]))
numbers = [1,2,100.01,90,45,3,4,5]
print(numbers)
print("Mayor", max(numbers))
print("Menor", min(numbers))
del numbers[-1] #SIRVE PARA ELIMINAR ELEMENTOS DE LA LISTA
print(numbers)
del numbers[:2]
print(numbers)
del numbers
print(numbers)