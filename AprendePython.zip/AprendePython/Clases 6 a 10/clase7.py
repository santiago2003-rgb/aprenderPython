#OPERADORES NUMERICOS = operaciones matematicas 
a = 10
b = 3
print("Suma: ", a + b)
print("Resta: ", a - b)
print("Multiplicacion: ", a * b)
print("Potenciacion: ", a ** b) #POTENCIA **
print("Division: ", a/b)
print("Parte entera de la division: ", a//b)
print("Modulo: ", a % b) #MODULOS %
a += 2
print(a)
#PENDAS
operation = 2 + 3 * 4
operation2 = (2 + 3) * 4
print(operation)
print(operation2)
operation3 = (2 + 3) * (4**2)/ 8 - 1
print(operation3)