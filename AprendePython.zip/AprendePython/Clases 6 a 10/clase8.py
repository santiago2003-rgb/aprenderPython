#OPERACIONES DE ENTRADA Y DE SALIDAS EN CONSOLA
#input
nombre = input("Ingrese su nombre: ")
print(nombre)
print(type(nombre))

edad = int(input("Ingrese su edad: "))
print(edad)
print(type(edad))
