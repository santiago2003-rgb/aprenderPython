#8.IMPRESION CON FORMATO ESPECIFICO
#Puedes controlar el formato de los números al imprimir. En este ejemplo, :.2f indica que el número debe mostrarse con dos decimales. Así, imprimirá “Valor: 3.14”, redondeando el número a dos decimales. Esto es especialmente útil cuando trabajas con datos numéricos y necesitas un formato específico.

valor = 3.14159
print("Valor: {:.2f}".format(valor))
#Resultado:

#Valor: 3.14

#9.SALTOS DE LINEA = \n
print("Hola\nmundo")

print("La ruta de archivo: C:\\Users\\Usuario\\Desktop\\Archivo.txt")