class Vehicle:
    def __init__(self, marca, modelo, precio):
        self.marca = marca
        self.modelo = modelo
        self.precio = precio
        self.disponible = True
    
    def vender(self):
        if self.disponible:
            self.disponible = False
            print(f'El vehiculo {self.marca}. Ha sido vendido')
        else:
            print(f'El vehiculo {self.marca}. No esta disponible')
            
    def estadoDisponible(self):
        return self.disponible
    
    def obtenerPrecio(self):
        return self.precio
    
    def iniciarFuncionamiento(self):
        raise NotImplementedError('Este metodo debe ser implementado por la subclase')
    
    def pararFuncionamiento(self):
        raise NotImplementedError('Este metodo debe ser implementado por la subclase')
    
class Car(Vehicle):
    def iniciarFuncionamiento(self):
        if  not self.disponible:
            return f'El  motor del coche {self.marca} esta en marcha'
        else:
            return f'El coche {self.marca} no esta disponible'
        
        
    def pararFuncionamiento(self):
        if self.disponible:
            return f'El coche {self.marca} se ha detenido'
        else:
            return f'El coche {self.marca} no esta disponible'

class Bike(Vehicle):
    def iniciarFuncionamiento(self):
        if not self.disponible:
            return f'La bicicleta {self.marca} esta en marcha'
        else:
            return f'La bicicleta {self.marca} no esta disponible'
        
    def pararFuncionamiento(self):
        if self.disponible:
            return f'La bicicleta {self.marca} se ha detenido'
        else:
            return f'La bicicleta {self.marca} no esta disponible'
    
class Truck(Vehicle):
    def iniciarFuncionamiento(self):
        if not self.disponible:
            return f'El motor del camion {self.marca} esta en marcha'
        else:
            return f'El camion {self.marca} no esta disponible'
        
    def pararFuncionamiento(self):
        if self.disponible:
            return f'El motot del camion {self.marca} se ha detenido'
        else:
            return f'El camion {self.marca} no esta disponible'

class Customer:
    def __init__(self, nombre):
        self.nombre = nombre
        self.compradoresVehiculos = []
        
    def comprarVehiculo(self, vehiculo: Vehicle):
        if vehiculo.estadoDisponible():
            vehiculo.vender()
            self.compradoresVehiculos.append(vehiculo)
        else:
            print(f'Lo  siento {vehiculo.marca} no esta disponible')
            
    def  consultarVehiculo(self, vehiculo:Vehicle):
        if vehiculo.estadoDisponible():
            disponibilidad = 'Disponible'
        else:
            disponibilidad = 'No disponible'
        print(f'El  {vehiculo.marca} esta {disponibilidad}y cuesta {vehiculo.obtenerPrecio()}')
        
class Dealership:
    def __init__(self):
        self.inventario = []
        self.clientes =  []
        
    def añadirVehiculos(self, vehiculo: Vehicle):
        self.inventario.append(vehiculo)
        print(f'El {vehiculo.marca} ha  sido añadido al inventario')
        
    def registrarCliente(self, cliente: Customer):
        self.clientes.append(cliente)
        print(f'El cliente  {cliente.nombre} ha sido añadido al inventario')
                
    def mostrarVehiculosDisponible(self):
        print('Vehiculos disponibles en la tienda: ')
        for vehiculo in self.inventario:
            if vehiculo.estadoDisponible():
                print(f'El vehiculo {vehiculo.marca} por {vehiculo.obtenerPrecio()}')
        
car1 = Car("Toyota", "Corolla", 20000)
bike1 = Bike("Yamaha", "MT-07", 7000)
truck1 = Truck("Volvo", "FH16", 80000)

customer1 = Customer("Carlos")

dealership = Dealership()
dealership.añadirVehiculos(car1)
dealership.añadirVehiculos(bike1)
dealership.añadirVehiculos(truck1)

#Mostra vehiculos disponibles
dealership.mostrarVehiculosDisponible()

#Cleinte consultar un vehiculo
customer1.consultarVehiculo()