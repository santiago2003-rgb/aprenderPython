''''class Person:
    def __init__ (self, name, age):
        self.name = name
        self.age = age
    def greet(self):
        print(f'Hola, mi nombre es {self.name} y tengo {self.age}')
    
person1 = Person('Ana', 30)
person2 = Person('Luis', 25)

person1.greet()
person2.greet()'''

#BankAccount
class BankAccount:
    def __init__(self, accountHolder, balance):
        self.accountHolder = accountHolder
        self.balance = balance
        self.isActive = True
    
    def deposit(self, amount):
        if self.isActive:
            self.balance += amount
            print(f'Se ha depositado {amount}. Saldo actual {self.balance}')
        else:
            print('No se puede depositar, cuenta inactiva')
                    
    def withdraw(self, amount):
        if self.isActive:
            if amount <= self.balance:
                self.balance -= amount
                print(f'Se ha retirado {amount}. Saldo actual {self.balance}')
                
    def deactivateAccount(self):
        self.isActive = False
        print(f'La cuenta ha sido desactivada')
        
    def activateAccount(self):
        self.isActive = True
        print(f'La cuenta ha sido activada')
        
account1 = BankAccount('Ana', 500)
account2 = BankAccount('Luis', 1000)

#Llamada del los metodos
account1.deposit(200)
account2.deposit(100)
account1.deactivateAccount()
account1.deposit(50)
account1.activateAccount()
account1.deposit(50)
