class Book:
    def __init__(self, title, author):
        self.title = title
        self.author = author
        self.avaliable = True
    
    def borrow(self):
        if self.avaliable:
            self.avaliable = False
            print(f'El libro {self.title} ha sidp prestado')
        else:
            print(f'El libro {self.title} no esta disponible')
            
    def returnBook(self):
        self.avaliable = True
        print(f'El libro {self.title} ha sido devuelto')
        
class User:
    def __init__(self, name, userId):
        self.name = name
        self.userId = userId
        self.borrowedBooks = []
        
    def borrowBook(self, book):
        if book.avaliable:
            book.borrow()
            self.borrowedBooks.append(book)
        else:
            print(f'El libro{book.title} No esta disponible')
    
    def returnBook(self, book):
        if book in self.borrowedBooks:
            book.returnBook()
            self.borrowedBooks.remove(book)
        else:
            print(f'El libro {book.title} no esta en la lista de prestados')
    
class Library:
    def __init__(self):
        self.books = []
        self.users = []
        
    def addBook(self, book):
        self.books.append(book)
        print(f'El libro {book.title} ha sido agregado')
        
    def registerUser(self, user):
        self.users.append(user)
        print(f'El usuario {user.name} ha sido registrado')
    
    def showAvaliableBooks(self):
        print('Libros disponibles: ')
        for book in self.books:
            if book.avaliable:
                print(f'{book.title} por {book.author}')
#Crear los liblos
book1 = Book('El principito', 'Antoine de Saint')
book2 = Book('1984', 'George Orwell')

#Crear usuario
user1 = User('Santiago', '001')

#Crear la biblioteca
library = Library()
library.addBook(book1)
library.addBook(book2)
library.registerUser(user1)

#Mostrar los libros
library.showAvaliableBooks()

#Realizar prestamo
user1.borrowBook(book1)

#Mostrar los libros
library.showAvaliableBooks()

#Devolver libro
user1.returnBook(book1)

#Mostrar los libros
library.showAvaliableBooks()

        