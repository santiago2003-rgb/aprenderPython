#VARIABLES 
'''print("Hola")
print("Mundo")'''
saludo1 = "Hola"
saludo2 = "Hi"
nombre = "Santiago"
print(saludo1)
print(nombre)