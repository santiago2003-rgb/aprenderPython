#CADENAS
name = 'SANTIAGO'
lastName = 'Mejia Garcia'
print(name)
print(name + ' ' + lastName)
#LEN DEVUELVE LA LONGITUD DE LA CADENA O TAMBIEN EL NUMERO DE ESPACIOS QUE TIENE
print(len(name))
print(len(lastName))
#METODO
#LOWER ES MINUSCULA
print(name.lower())
#UPPER ES MAYUSCULA 
print(name.upper())
#STRIP ES ESPACIOS
print(lastName.strip())


