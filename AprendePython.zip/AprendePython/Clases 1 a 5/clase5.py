#DATOS ENTEROS, FLOTANTE Y BOOLEANOS
x = 10 
y = 5.678
#z = 1.2e6
#a = 1.2e-6
print(type(x))
print(type(y))
#print(z)
#print(a)
print(x + x)
print(y + y) 
print(x + y) #Resultados flotantes

#BOOLEANOS
isTrue = True
isFalse = False
print(isTrue)
print(type(isTrue))
print(isFalse)

