#1. PIDE AL USUARIO QUE INGRESE DOS NUMEROS Y MUSTRE POR SALIDA LA SUMA DE ELLOS
'''print('Primer numero: ')
num1 = int(input())
print('Segundo numero: ')
num2 = int(input())
suma = num1 + num2
print('El resultado de la suma es: ', suma)'''

#2. Pide al usuario que ingrese un número y determina si es par o impar.
'''print('Ingresa un numero: ')
numero = int(input())
if numero % 2 == 0:
    print('El numero es par')
else:
    print('El numero es impar')'''

#3. Pide al usuario que ingrese dos números y muestra el resultado de su multiplicación.
'''num1 = int(input('Ingrese el primer numero: '))
num2 = int(input('Ingrese el segundo numero: '))
resultado = num1 * num2
print('El resultado de la multipicacion es: ', resultado)'''

#4. Escribe un programa que pida al usuario su nombre y lo salude con un mensaje personalizado.

'''nombreUser = input('Ingrese su nombre: ')
print(f'Hola, bienvenido: ', {nombreUser})'''

#5. Escribe un programa que reciba tres números y determine cuál es el mayor de ellos.
'''num1 = input('Primer numero: ')
num2 = input('Segundo numero: ')
num3 = input('Tercer numero: ')
mayor = max(num1, num2, num3)
print(f'El numero mayor es: ', mayor)'''

#6.
'''import math
radio = float(input('Introducce el radio del circulo: '))
area = math.pi * radio ** 2
print('El area del circulo es: ', area)'''

#7. 
'''palabra = input('Introducce una palabra: ')
vocales = 'aeiouAEIOU'
contador = 0
for letra in palabra:
    if letra in vocales:
        contador = contador + 1
print('La palabra tiene', contador ,'vocales')'''

#8.
try:
    numero = float(input('Digita un numero: '))
    if numero == 0:
        print('Es igual a 0')
    elif numero < 0:
        print('El numero es negativo')
    elif numero > 0:
        print('El numero es positivo')
except ValueError:
  print('No valido, ingrese lo que pide')
    