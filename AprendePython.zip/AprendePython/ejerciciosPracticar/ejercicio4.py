def numImpar(limit):
    a = 1
    while a < limit + 1:
        yield a
        a = a + 2
for num in numImpar(11):
    print(num)

print('------------------------------')

def numPares(limit):
    b = 0
    while b < limit + 1:
        yield b
        b = b + 2
for num in numPares(12):
    print(num)