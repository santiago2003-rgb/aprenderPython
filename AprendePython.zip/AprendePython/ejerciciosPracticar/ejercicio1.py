numbers = [1, 2, 3, 4, 5]
dobles = [x * 2 for x in numbers]
print("Dobles: ",dobles)