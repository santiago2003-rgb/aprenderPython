print('JUEGO DE PIEDRA PAPEL O TIJERA')
print('JUGADOR 1 INGRESE SU NOMBRE : ')
player1 = input()
print('JUGADOR 2 INGRESE SU NOMBRE : ')
player2 = input()
print(player1, 'Ingresa que eliges: ¿Piedra, papel o tijeras: ')
player1Move = input().lower()
print(player2, 'Ingresa que eliges: ¿Piedra, papel o tijeras: ')
player2Move = input().lower()

validMoves = ['piedra', 'papel', 'tijeras']

if player1Move not in validMoves or player2Move not in validMoves:
    print('Uno ambos hicieron una eleccion no valida. Por favor elijan entre las opciones disponibles')
else:
    if player1Move == player2Move:
        print('Empate')
    elif (player1Move == 'piedra' and player2Move == 'tijera') or (player1Move == 'tijera' and player2Move == 'papel') or (player1Move == 'papel' and player2Move == 'piedra'):
        print('Gana: ', player1)
    else:
        print('Gana: ', player2)
    