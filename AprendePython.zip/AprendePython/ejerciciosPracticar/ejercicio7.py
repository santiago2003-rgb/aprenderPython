#CONCESIONARIO
class Vehivulo:
    def __init__(self, modelo, precio):
        self.modelo = modelo
        self.precio = precio
        self.disponible = True
    
    def vender(self):
        if self.disponible:
            self.disponible = False
            print(f'El vehiculo {self.modelo} ha sido vendido')
        else:
            print(f'El vehiculo {self.modelo} no esta disponible')
        
    def hacerDisponible(self):
        self.disponible = True
        print(f'El vehiculo {self.modelo} esta disponible para la venta nuevamente')
        
class Cleinte:
    def __init__(self, nombre, clienteId):
        self.nombre = nombre
        self.clienteId = clienteId
        self.vehiculosComprados = []
    
    def comprarVehiculo(self, vehiculo):
        if vehiculo.disponible:
            vehiculo.vender()
            self.vehiculosComprados.append(vehiculo)
        else:
            print(f'El vehiculo {vehiculo.modelo} no esta disponible')
        
    def devolverVehiculo(self, vehiculo, concesionario):
        if vehiculo in self.vehiculosComprados:
            vehiculo.hacerDisponible()
            self.vehiculosComprados.remove(vehiculo)
        else:
            print(f'El vehiculo {vehiculo.modelo} no esta en la lista de comprados')

class Concesionario:
    def __init__(self):
        self.vehiculos = []
        self.clientes = []
        
    def agragarVehiculo(self, vehiculo):
        self.clientes.append(vehiculo)
        print(f'El vehiculo {vehiculo.modelo} ha sido agregado al inventario')
        
    def registrarCliente(self, cliente):
        self.clientes.append(cliente)
        print(f'El cliente {cliente.nombre} ha sido registrado')
    
    def mostrarVehiculoDisponible(self):
        print('VEHICULOS DISPONIBLE: ')
        for vehiculo in self.vehiculos:
            if vehiculo.disponible:
                print(f'{vehiculo.modelo} por {vehiculo.precio}')

# Crear los vehículos
vehiculo1 = Vehivulo('Dlorean', 1500)
vehiculo2 = Vehivulo('Mazda', '600')

cliente1 = Cleinte('Alex', '001')

concesionario = Concesionario()
concesionario.agragarVehiculo(vehiculo1)
concesionario.agragarVehiculo(vehiculo2)
concesionario.registrarCliente(cliente1)

concesionario.mostrarVehiculoDisponible()

cliente1.comprarVehiculo(vehiculo1)

concesionario.mostrarVehiculoDisponible()

cliente1.devolverVehiculo(vehiculo1, concesionario)

concesionario.mostrarVehiculoDisponible()