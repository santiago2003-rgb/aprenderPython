palabras = ["sol", "mar", "montaña", "rio", "estrella"]
palabrasFiltradas = [palabra.upper()for palabra in palabras if len(palabra)]
print("Palabras filtradas y en mayuscula: ", palabrasFiltradas)