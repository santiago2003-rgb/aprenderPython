def sumatoriaNumeros(n):
    if n == 0:
        return 0
    else:
        return n + sumatoriaNumeros(n-1)
    
for i in range(6):
    print('La sumatoria de', i , 'es: ', sumatoriaNumeros(i))    