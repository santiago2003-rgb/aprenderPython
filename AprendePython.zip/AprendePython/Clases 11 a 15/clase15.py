#EJEMPLO DE ITERADORES

#Crear una lista
lista = [1, 2, 3, 4]
#Obtener el iterador
myIter = iter(lista)
#Usar el iterador
print(next(myIter)) #next nos permite ver cuales son los valores que se van guardando en memoria 
print(next(myIter))
print(next(myIter))
print(next(myIter))
print(next(myIter))

#ITERADORES CADENAS
#Creando la cadena
text = 'hola mundo'
#Creando el iterador
iterText = iter(text)
#iterar en la cadena
for char in iterText:
    print(char)
    
#ITERADORES IMPARES
#Crear un interador para los numeros impares
limit = 10
#Crear iterador
oddItter = iter(range(1, limit + 1, 2))
#Usar un iterador
for num in oddItter:
    print(num)
    
#GENERADORES
def myGenerator():
    yield 1
    yield 2
    yield 3
for value in myGenerator():
    print(value)
    
#FIBONACHI
def fibonachi(limit):
    a, b = 0,1
    while a < limit:
        yield a
        a, b = b, a + b
for num in fibonachi(20):
    print(num)


