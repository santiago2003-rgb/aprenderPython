#COMPRESION DE LIST
#Listas van con corchetes
squares = [x**2 for x in range(1, 11)]
#print('Cuadrados: ', squares)
celcius = [0, 10, 29, 30, 40]
fahrenheit = [(temp * 9/5)*32 for temp in celcius]
#print("Temperatura en F: ", fahrenheit)

#Hallar los numeros pares
evens = [x for x in range(1, 21) if x % 2 == 0]
#print(evens)

matrix = [[1, 2, 3],
          [4, 5, 6],
          [7, 8 ,9]]
transposed = [[row[i] for row in matrix] for i in range(len(matrix[0]))]
print(matrix)
print(transposed)

#CONCLUSION: El compresion list sirve para hacer el codigo mas eficiente y evitar menos lineas de codigo, legible, elegante 
