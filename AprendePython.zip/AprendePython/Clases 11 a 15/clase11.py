#DICCIONARIOS
#Los diccionarios se inicina con llaves y ya
numbers = {
    1:"Uno",
    2:"dos",
    3:"tres"
}
print(numbers[2])

information = {
    "Nombre": "Santiago",
    "Apellido": "Mejia Garcia",
    "Altura": 1.63,
    "Edad": 21
}
print(information)
del information["Edad"] #Sirve para eliminar 
print(information)

#METODO KEYS = LLAVES
claves = information.keys()
print(claves)
print(type(claves))
values = information.values(),
print(values)
pairs = information.items()
print(pairs)

contacts = { "Santiago":
    {
        "Apellido": "Mejia Garcia",
        "Altura": 1.63,
        "Edad": 21
    },
    "Heidy":{
        "Apellido": "Quiceno",
        "Altura": 1.60,
        "Edad": 18
    },
}
print(contacts["Santiago"]["Apellido"])
print(contacts["Santiago"]["Altura"])
print(contacts["Santiago"]["Edad"])