x = 15
y = 20

if x > 10 and y > 25: #AND = que las dos condiciones sean verdaderas
    print("X es mayor que 10 y Y es mayor que 15")
if x > 10 or y > 25: #OR = necesita que una de las dos condicione sea verdadera
    print("X es mayor que 10 o Y es mayor que 25")
if not x > 10:
    print("X no es mayor que 10")
