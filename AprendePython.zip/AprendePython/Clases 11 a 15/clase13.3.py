isMember = True
age = 11
if isMember:
    if age >= 15:
        print("Tienes acceso ya que eres miembro y mayor o igual a 15 años")
    else:
        print("No tienes acceso ya que eres miembro pero menor de 15")
else:
    print("No eres miembro y NO TIENES ACCESO")