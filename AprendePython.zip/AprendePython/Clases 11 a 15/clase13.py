#ESTRUCTURAS CONDICIONALES
#if y else
#Se pueden evaluar varias condiciones
x = 10
if x > 5:
    print("X es mayor que 5")
elif x == 5:
    print("X es igual que 5")
else:
    print("X no es menor que 5")
print("Fuera")