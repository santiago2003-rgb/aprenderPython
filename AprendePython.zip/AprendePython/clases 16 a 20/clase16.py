#FUNCIONES 
#Se definen con el def

def greet(name, lastName = 'No tiene apellido'):
    print('Hola', name, lastName)
greet('Santiago','Mejia')
greet('Heidy')
greet(lastName = 'Mejia', name = 'Santiago')

#FUNCIONES CALCULADORA
def sumar(a, b):
    return a + b

def restar(a, b):
    return a - b

def multiplicacion(a, b):
    return a * b

def dividir(a, b):
    return a / b

def calculadora():
    while True:
        print('Seleccione una operacion')
        print('1. Suma')
        print('2. Resta')
        print('3. Multiplicacion')
        print('4. Division')
        print('5. Salir')
        
        opcion = input('Ingrese una opcion (1,2,3,4,5): ')
        
        if opcion == '5':
            print('Saliendo de la calculadora')
            break
        if opcion in ['1', '2', '3', '4']:
            num1 = float(input('Ingrese el primer numero: '))
            num2 = float(input('Ingrese el segundo numero: '))
            
            if opcion == '1':
                print('La suma es: ', sumar(num1, num2))
            elif opcion == '2':
                print('La resta es: ', restar(num1, num2))
            elif opcion == '3':
                print('La multiplicacion es: ', multiplicacion(num1, num2))
            elif opcion == '4':
                print('La division es: ', dividir(num1, num2))
        else:
            print('Opcion no validad, por favor intenta de nuevo')
calculadora()
            