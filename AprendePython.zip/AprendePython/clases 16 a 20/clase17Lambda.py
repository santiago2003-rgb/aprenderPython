#FUNCIONES LAMBDA Y PROGRAMACION FUNCIONAL
suma = lambda a, b: a + b
print(suma(10, 4))

multiplicacion = lambda a, b: a * b
print(multiplicacion(80, 5))

#CUADRADO DE CADA NUMERO
numbers = range(11)
squaredNumbers = list(map(lambda x: x **2, numbers))
print('Cuadrados: ', squaredNumbers)


#Pares 
evenNumbers = list(filter(lambda x: x % 2 == 0, numbers))
print('Pares: ', evenNumbers)

