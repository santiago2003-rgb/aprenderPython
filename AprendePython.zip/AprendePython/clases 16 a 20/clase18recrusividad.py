#RECURSIVIDAD
def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n - 1)

factorial_5 = print(factorial(5))

#FIBONACHI
def fibonachi(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return n + fibonachi(n - 1)

number = 0
print(fibonachi(number))